/*Crear procedimientos para manipular datos 
Utilizaremos SQL Server Management Studio para definir un procedimiento que nos permita insertar un registro en la tabla. 
Copia la siguiente sentencia en SQL Server Management Studo */

IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'creaMaterial' AND type = 'P')
   DROP PROCEDURE creaMaterial
GO
            
CREATE PROCEDURE creaMaterial
	@uclave NUMERIC(5,0),
    @udescripcion VARCHAR(50),
    @ucosto NUMERIC(8,2),
    @uimpuesto NUMERIC(6,2)
AS
  INSERT INTO Materiales VALUES(@uclave, @udescripcion, @ucosto, @uimpuesto)
GO

/*Para ejecutar el stored procedure, se utiliza la sintaxis mostrada en el siguiente ejemplo:  */
EXECUTE creaMaterial 5000,'Martillos Acme',250,15 

/*modificaMaterial que permite modificar un material que reciba como par�metros las columnas de la
 tabla materiales y actualice las columnas correspondientes con los valores recibidos, para el registro cuya llave sea la clave que se recibe como par�metro. */

IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'modificaMaterial' AND type = 'P')
   DROP PROCEDURE modificaMaterial
GO
 
/*eliminaMaterial que elimina el registro de la tabla materiales cuya llave sea la clave que se recibe como par�metro. */      
CREATE PROCEDURE modificaMaterial
	@uclave NUMERIC(5,0),
    @udescripcion VARCHAR(50),
    @ucosto NUMERIC(8,2),
    @uimpuesto NUMERIC(6,2)
AS
  UPDATE Materiales SET descripcion = @udescripcion, costo = @ucosto,  PorcentajeImpuesto = @uimpuesto
  WHERE clave = @uclave
GO


IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'eliminarMaterial' AND type = 'P')
   DROP PROCEDURE eliminarMaterial
GO
            
CREATE PROCEDURE eliminarMaterial
	@uclave NUMERIC(5,0)  
AS
  DELETE FROM Materiales 
  WHERE clave = @uclave
GO

EXECUTE creaMaterial 5000,'hola',150.00,2.43
SELECT * FROM Materiales
EXECUTE modificaMaterial 5000,'jamon',150.00,2.43
EXECUTE eliminarMaterial 5000

/* Desarrollar los procedimientos (almacenados) creaProyecto , modificaproyecto y eliminaproyecto, hacer lo mismo para las
 tablas proveedores y entregan.*/

 /*Proyectos*/
IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'creaProyecto' AND type = 'P')
   DROP PROCEDURE creaProyecto
GO
            
CREATE PROCEDURE creaProyecto
	@unumero NUMERIC(5,0),
    @udenominacion VARCHAR(50)
AS
  INSERT INTO Proyectos VALUES(@unumero, @udenominacion)
GO

IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'modificaProyecto' AND type = 'P')
   DROP PROCEDURE modificaProyecto
GO
            
CREATE PROCEDURE modificaProyecto
	@unumero NUMERIC(5,0),
    @udenominacion VARCHAR(50)
AS
  UPDATE Proyectos SET Denominacion = @udenominacion
  WHERE numero = @unumero
GO

IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'eliminarProyecto' AND type = 'P')
   DROP PROCEDURE eliminarProyecto
GO
            
CREATE PROCEDURE eliminarProyecto
	@unumero NUMERIC(5,0)
AS
  DELETE FROM Proyectos
  WHERE numero = @unumero
GO

EXECUTE creaProyecto 10080, 'Pokemon'
SELECT * FROM Proyectos
EXECUTE modificaProyecto 10080, 'Coca'
EXECUTE eliminarProyecto 10080 

/*Proveedores*/
IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'creaProveedor' AND type = 'P')
   DROP PROCEDURE creaProveedor
GO
            
CREATE PROCEDURE creaProveedor
	@urfc CHAR(13),
    @urazonsocial VARCHAR(50)
AS
  INSERT INTO Proveedores VALUES(@urfc, @urazonsocial)
GO

IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'modificaProveedor' AND type = 'P')
   DROP PROCEDURE modificaProveedor
GO
            
CREATE PROCEDURE modificaProveedor
	@urfc CHAR(13),
    @urazonsocial VARCHAR(50)
AS
  UPDATE Proveedores SET RazonSocial = @urazonsocial
  WHERE RFC = @urfc
GO

IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'eliminarProveedor' AND type = 'P')
   DROP PROCEDURE eliminarProveedor
GO
            
CREATE PROCEDURE eliminarProveedor
	@urfc CHAR(13)
AS
  DELETE FROM Proveedores
  WHERE RFC = @urfc
GO

EXECUTE creaProveedor 'AKA49', 'John Cena'
SELECT * FROM Proveedores
EXECUTE modificaProveedor 'AKA49', 'Godzilla'
EXECUTE eliminarProveedor 'AKA49' 

/*Entregan*/
IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'creaEntrega' AND type = 'P')
   DROP PROCEDURE creaEntrega
GO
            
CREATE PROCEDURE creaEntrega
	@uclave NUMERIC(5,0),
    @urfc CHAR(13),
	@unumero NUMERIC(5,0),
	@ufecha DATETIME,
	@ucantidad NUMERIC(8,2)
AS
  INSERT INTO Entregan VALUES(@uclave, @urfc, @unumero, @ufecha, @ucantidad)
GO

IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'modificaEntrega' AND type = 'P')
   DROP PROCEDURE modificaEntrega
GO
            
CREATE PROCEDURE modificaEntrega
	@uclave NUMERIC(5,0),
    @urfc CHAR(13),
	@unumero NUMERIC(5,0),
	@ufecha DATETIME,
	@ucantidad NUMERIC(8,2)
AS
  UPDATE Entregan SET Cantidad = @ucantidad
  WHERE RFC = @urfc AND Clave = @uclave AND Numero = @unumero AND Fecha = @ufecha
GO

IF EXISTS (SELECT name FROM sysobjects 
            WHERE name = 'eliminarEntrega' AND type = 'P')
   DROP PROCEDURE eliminarEntrega
GO
            
CREATE PROCEDURE eliminarEntrega
	@uclave NUMERIC(5,0),
    @urfc CHAR(13),
	@unumero NUMERIC(5,0),
	@ufecha DATETIME
AS
  DELETE FROM Entregan
  WHERE RFC = @urfc AND Clave = @uclave AND Numero = @unumero AND Fecha = @ufecha
GO

EXECUTE creaProveedor 'AKA49', 'John Cena'
SELECT * FROM Proveedores
EXECUTE modificaProveedor 'AKA49', 'Godzilla'
EXECUTE eliminarProveedor 'AKA49' 

-------------------------------------------------------------------------------
/*Crear procedimientos para realizar consultas con par�metros */

/*Define el siguiente store procedure en tu base de datos: */
                            IF EXISTS (SELECT name FROM sysobjects 
                                       WHERE name = 'queryMaterial' AND type = 'P')
                                DROP PROCEDURE queryMaterial
                            GO
                            
                            CREATE PROCEDURE queryMaterial
                                @udescripcion VARCHAR(50),
                                @ucosto NUMERIC(8,2)
                            
                            AS
                                SELECT * FROM Materiales WHERE descripcion 
                                LIKE '%'+@udescripcion+'%' AND costo > @ucosto 
                            GO
                            
/*Ejec�talo con la siguiente instrucci�n */

EXECUTE queryMaterial 'Lad',20 



