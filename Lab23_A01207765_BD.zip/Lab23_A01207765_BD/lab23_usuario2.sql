
/*----------------------------------------------Lab 23-Usuario-2-------------------------------------------------------------------------------------------------------*/


SELECT * FROM CLIENTES_BANCA 

BEGIN TRANSACTION PRUEBA2
INSERT INTO CLIENTES_BANCA VALUES('004','Ricardo Rios Maldonado',19000);
INSERT INTO CLIENTES_BANCA VALUES('005','Pablo Ortiz Arana',15000); 
INSERT INTO CLIENTES_BANCA VALUES('006','Luis Manuel Alvarado',18000); 

SELECT * FROM CLIENTES_BANCA where NoCuenta='001' 

ROLLBACK TRANSACTION PRUEBA2







