
select * from materiales 

select * from materiales 
where clave=1000 

select clave,rfc,fecha from entregan 

select * from materiales,entregan 
where materiales.clave = entregan.clave 

select * from entregan,proyectos 
where entregan.numero < = proyectos.numero 


(select * from entregan where clave=1450) 
union 
(select * from entregan where clave=1300) 

select * from entregan where clave=1300 OR clave=1450


(select clave from entregan where numero=5001) 
intersect 
(select clave from entregan where numero=5018) 

(select * from entregan) 
minus 
(select * from entregan where clave=1000) 

select * from entregan,materiales 

set dateformat dmy
select  descripcion, fecha from materiales m , entregan e where m.clave = e.clave AND fecha BETWEEN '01/01/2000' AND '31/12/2000'

select distinct  descripcion, fecha from materiales m , entregan e where m.clave = e.clave AND fecha BETWEEN '01/01/2000' AND '31/12/2000'

select pr.Numero, pr.Denominacion, e.Fecha, e.Cantidad
from materiales m,entregan e, proyectos pr 
where m.Clave = e.Clave AND pr.Numero = e.Numero 
order by Fecha desc


SELECT * FROM materiales where Descripcion LIKE 'Si%' 

DECLARE @foo varchar(40); 
DECLARE @bar varchar(40); 
SET @foo = '�Que resultado'; 
SET @bar = ' ���??? ' 
SET @foo += ' obtienes?'; 
PRINT @foo + @bar; 


SELECT RFC FROM Entregan WHERE RFC LIKE '[A-D]%'; 

SELECT RFC FROM Entregan WHERE RFC LIKE '[^A]%'; 

SELECT Numero FROM Entregan WHERE Numero LIKE '___6'; 

SELECT RFC,Cantidad, Fecha,Numero 
FROM [Entregan] 
WHERE [Numero] Between 5000 and 5010 AND     
Exists ( SELECT [RFC] 
FROM [Proveedores] 
WHERE RazonSocial LIKE 'La%' and [Entregan].[RFC] = [Proveedores].[RFC] ) 





SELECT RFC,Cantidad, Fecha,Numero 
FROM [Entregan] 
WHERE [Numero] Between 5000 and 5010 AND [RFC]     
IN ( SELECT [RFC] 
FROM [Proveedores] 
WHERE RazonSocial LIKE 'La%' and [Entregan].[RFC] = [Proveedores].[RFC] ) 

SELECT RFC,Cantidad, Fecha,Numero 
FROM [Entregan] 
WHERE [Numero] Between 5000 and 5010 AND [RFC]     
NOT IN ( SELECT [RFC] 
FROM [Proveedores] 
WHERE RazonSocial NOT LIKE 'La%' and [Entregan].[RFC] = [Proveedores].[RFC])

SELECT  Descripcion 
FROM Materiales
WHERE Clave= ANY ( SELECT Clave From Entregan Where cantidad = 1  )  

SELECT TOP 2 * FROM Proyectos 

SELECT TOP Numero FROM Proyectos

ALTER TABLE materiales ADD PorcentajeImpuesto NUMERIC(6,2); 

UPDATE materiales SET PorcentajeImpuesto = 2*clave/1000; 

SELECT * FROM Materiales WHERE descripcion = 'Arena'
SELECT * FROM Entregan WHERE clave =1240


select sum((m.costo+ m.costo *(m.PorcentajeImpuesto/100))*e.cantidad) as Total 
from Entregan e, Materiales m
where e.clave = m.clave 

select denominacion from proyectos

select *
	from Materiales m, Entregan e, Proyectos pr
	where m.clave = e.clave AND pr.numero = e.numero AND pr.denominacion LIKE 'Mexico sin ti no estamos completos'


CREATE VIEW MexicoSinTiNoEstamosCompletos( clave, descripcion ) as
(
	select  m.clave, m.descripcion 
	from Materiales m, Entregan e, Proyectos pr
	where m.clave = e.clave AND pr.numero = e.numero AND pr.denominacion LIKE 'Mexico sin ti no estamos completos'
)
select * from MexicoSinTiNoEstamosCompletos

CREATE VIEW AcmeTools ( clave, descripcion ) as
(
	select  m.clave, m.descripcion 
	from Materiales m, Entregan e, Proveedores pr
	where m.clave = e.clave AND pr.rfc = e.rfc AND pr.RazonSocial LIKE 'Acme Tools'
)
select * from AcmeTools

DROP VIEW AcmeTools

select * from proyectos

SET DATEFORMAT dmy
SELECT  RFC, SUM(E.Cantidad) as 'TOTAL'
FROM Entregan e
WHERE e.Fecha BETWEEN '1/1/2000' AND '31/12/2000'
GROUP BY RFC
HAVING SUM(e.Cantidad)>= 300

SET DATEFORMAT dmy
SELECT M.Descripcion, SUM(e.Cantidad) as 'TOTAL'
FROM Materiales m, Entregan e
WHERE e.Fecha BETWEEN '1/1/2000' AND '31/12/2000'
GROUP BY m.Descripcion

 
CREATE VIEW Total_2001 as
(
SELECT SUM(Cantidad) as 'TOTAL'
FROM Entregan
WHERE Fecha BETWEEN '1/1/2001' AND '31/12/2001'
GROUP BY Clave
)

SELECT TOP 1 TOTAL FROM Total_2001

SELECT Descripcion
FROM Materiales
WHERE Descripcion LIKE '%ub%'

SELECT Denominacion, SUM(e.Cantidad* m.Costo*(1+porcentajeImpuesto/100)) as 'Total a pagar'
FROM Materiales m, Proyectos p, Entregan e
WHERE m.Clave = e.Clave AND p.Numero = e.Numero
GROUP BY Denominacion



DROP VIEW ProveedoresTelevisa
DROP VIEW ProveedoresCoahuila
DROP VIEW diferencia_Proveedores

CREATE VIEW Proveedores_Televisa (Denominacion, RFC, RazonSocial) as
(
	SELECT DISTINCT pr.Denominacion, p.RFC, p.RazonSocial
	FROM Proveedores p, Proyectos pr, Entregan e
	WHERE p.RFC = e.RFC AND pr.Numero = e.Numero AND pr.Denominacion LIKE 'Televisa en acci�n'
)

CREATE VIEW Proveedores_Coahuila (Denominacion, RFC, RazonSocial) as
(
	SELECT DISTINCT pr.Denominacion, p.RFC, p.RazonSocial
	FROM Proveedores p, Proyectos pr, Entregan e
	WHERE p.rfc = e.rfc AND pr.numero = e.numero AND pr.denominacion LIKE 'Educando en Coahuila'
)

CREATE VIEW diferencia_Proveedores As
(
	SELECT RazonSocial FROM Proveedores_Televisa
	EXCEPT
	SELECT RazonSocial FROM Proveedores_Coahuila
)

SELECT * FROM Proveedores_Televisa WHERE RazonSocial IN (SELECT * FROM diferencia_Proveedores)

SELECT DISTINCT p.Denominacion, pr.RFC, pr.RazonSocial  
from Entregan e, Proyectos p, Proveedores pr
WHERE e.RFC = pr.RFC AND p.Numero = e.Numero AND p.Denominacion LIKE 'Televisa en acci�n' and pr.RFC
NOT IN
(SELECT e.RFC
from Entregan e, Proyectos p
WHERE p.Numero = e.Numero AND p.Denominacion LIKE 'Educando en Coahuila')

CREATE VIEW Televisa_Coahuila as(
	SELECT m.Costo, m.Clave
	FROM Entregan e, proyectos p, Proveedores pr, materiales m
	WHERE p.numero=e.numero and pr.RFC=e.RFC and m.Clave = e.clave
	AND p.Denominacion='Televisa en acci�n'  AND pr.RFC  in (
	SELECT pr.RFC
	FROM Entregan e, Proyectos p, Proveedores pr, Materiales m
	WHERE p.numero=e.numero AND pr.RFC=e.RFC AND m.Clave = e.clave AND p.Denominacion='Educando en Coahuila')

)

SELECT * FROM Televisa_Coahuila
