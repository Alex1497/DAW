/*Alejandro �lvarez Palafox
A01207765
----------------------------------Lab 18-------------------------------------------------------------------*/


/*La suma de las cantidades e importe total de todas las entregas realizadas durante el 97. */
SET DATEFORMAT dmy
SELECT SUM(e.Cantidad) as 'Cantidad Total 1997', SUM(e.Cantidad*m.Costo*(1+(m.PorcentajeImpuesto/100))) as 'Importe Total 1997'
FROM Entregan e, Materiales m
WHERE e.Clave = m.Clave AND e.Fecha BETWEEN '01/01/1997' AND '31/12/1997'

/*Para cada proveedor, obtener la raz�n social del proveedor, n�mero de entregas e importe total de las entregas realizadas. */
SELECT p.RazonSocial, COUNT(e.RFC) as 'N�mero de entregas' , SUM(e.Cantidad*m.Costo*(1+(m.PorcentajeImpuesto/100))) as 'Importe Total'
FROM Proveedores p, Entregan e, Materiales m
WHERE p.RFC = e.RFC AND e.Clave = m.Clave
GROUP BY p.RazonSocial

/*Por cada material obtener la clave y descripci�n del material, la cantidad total entregada, la m�nima cantidad entregada, la m�xima 
cantidad entregada, el importe total de las entregas de aquellos materiales en los que la cantidad promedio entregada sea mayor a 400. */
SELECT m.Clave, m.Descripcion, SUM(e.Cantidad) as 'Cantidad total entregada', MAX(e.Cantidad) as 'Cantidad Max. entregada', MIN(e.Cantidad) as 'Cantidad min. entregada', SUM(e.Cantidad*m.Costo*(1+(m.PorcentajeImpuesto/100))) as 'Importe Total'  
FROM Materiales m, Entregan e
WHERE m.Clave = e.Clave
GROUP BY m.Clave, m.Descripcion
HAVING AVG(e.Cantidad) > 400

/*Para cada proveedor, indicar su raz�n social y mostrar la cantidad promedio de cada material entregado, detallando la clave y descripci�n
del material, excluyendo aquellos proveedores para los que la cantidad promedio sea menor a 500.*/
SELECT pv.RazonSocial, AVG(e.Cantidad) as 'Cantidad Promedio de Entrega', m.Clave, m.Descripcion
FROM Proveedores pv, Entregan e, Materiales m
WHERE pv.RFC = e.RFC AND e.Clave = m.Clave
GROUP BY pv.RazonSocial, m.Clave, m.Descripcion
HAVING AVG(e.Cantidad) >= 500

/*Mostrar en una solo consulta los mismos datos que en la consulta anterior pero para dos grupos de proveedores: aquellos para los que la cantidad promedio entregada 
es menor a 370 y aquellos para los que la cantidad promedio entregada sea mayor a 450. */
SELECT pv.RazonSocial, AVG(e.Cantidad) as 'Cantidad Promedio de Entrega', m.Clave, m.Descripcion
FROM Proveedores pv, Entregan e, Materiales m
WHERE pv.RFC = e.RFC AND e.Clave = m.Clave
GROUP BY pv.RazonSocial, m.Clave, m.Descripcion
HAVING AVG(e.Cantidad) < 370 OR AVG(e.Cantidad) >450

SELECT *
FROM Materiales

INSERT INTO Materiales VALUES (1500,'Tornillos de adamantium',500.00,2.85) ; 
INSERT INTO Materiales VALUES (1510,'Pintura KGTA',325.00,2.83) ; 
INSERT INTO Materiales VALUES (1520,'Grava de Ceramica',515.00,2.41) ; 
INSERT INTO Materiales VALUES (1530,'Tuercas de Diente de tibur�n',421.00,2.11) ;
INSERT INTO Materiales VALUES (1540,'Arena de Jupiter',1513.00,2.01) ;

/*Clave y descripci�n de los materiales que nunca han sido entregados.*/
SELECT m.Clave, m.Descripcion
FROM Materiales m
WHERE Clave NOT IN (SELECT Clave FROM Entregan) 

/*Raz�n social de los proveedores que han realizado entregas tanto al proyecto 'Vamos M�xico' como al proyecto 'Quer�taro Limpio'. */
SELECT RazonSocial 
FROM Proveedores
WHERE RFC IN (SELECT RFC
			  FROM Entregan e, Proyectos p
			  WHERE e.Numero = p.Numero
			  AND (p.Denominacion LIKE 'Vamos Mexico' OR p.Denominacion LIKE 'Queretaro Limpio'))


/*Descripci�n de los materiales que nunca han sido entregados al proyecto 'CIT Yucat�n'. */
SELECT Descripcion
FROM Materiales
WHERE Clave NOT IN (SELECT e.Clave
					FROM Entregan e, Proyectos p
					WHERE e.Numero = p.Numero
					AND p.Denominacion LIKE 'CIT Yucatan')


/*Raz�n social y promedio de cantidad entregada de los proveedores cuyo promedio de cantidad entregada es mayor al promedio de la cantidad entregada por
el proveedor con el RFC 'VAGO780901'.*/
SELECT p.RazonSocial, AVG(e.Cantidad) as 'Cantidad Promedio'
FROM Proveedores p, Entregan e
WHERE p.RFC = e.RFC
GROUP BY p.RazonSocial
HAVING AVG(e.Cantidad) > (SELECT AVG(e.Cantidad)
						  FROM Entregan
					      WHERE RFC LIKE 'VAGO780901')


/*RFC, raz�n social de los proveedores que participaron en el proyecto 'Infonavit Durango' y cuyas cantidades totales entregadas en el 2000 fueron mayores a las
cantidades totales entregadas en el 2001. */
CREATE VIEW Cantidad_2000(RFC, Cantidad) AS (
 	SELECT RFC, SUM(Cantidad) 
	FROM Entregan 
	WHERE Fecha BETWEEN '01/01/2000' AND '31/12/2000' 
	GROUP BY RFC
 )


CREATE VIEW Cantidad_2001(RFC, Cantidad) AS (
 	SELECT RFC, SUM(Cantidad) 
	FROM Entregan 
	WHERE Fecha BETWEEN '01/01/2001' AND '31/12/2001' 
	GROUP BY RFC
 )

 -
SET DATEFORMAT dmy
SELECT e.RFC, pr.RazonSocial
FROM Entregan e, Proveedores pr, Proyectos p, Cantidad_2000 c_2000, Cantidad_2001 c_2001 
where pr.RFC = e.RFC AND p.Numero = e.Numero AND e.RFC = c_2000.RFC and e.RFC = c_2001.RFC 
AND  c_2000.rfc = c_2001.RFC AND c_2000.Cantidad > c_2001.Cantidad
AND p.Denominacion LIKE 'Infonavit Durango' 
GROUP BY e.RFC, pr.RazonSocial
					      





