BULK INSERT a1207765.a1207765.[Proveedores]
   FROM 'e:\wwwroot\a1207765\proveedores.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

SELECT  * FROM Proveedores