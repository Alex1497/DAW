SET DATEFORMAT dmy

BULK INSERT a1207765.a1207765.[Entregan]   
   FROM 'e:\wwwroot\a1207765\entregan.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

	  SELECT  * FROM Entregan