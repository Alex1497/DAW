BULK INSERT a1207765.a1207765.[Materiales]
   FROM 'e:\wwwroot\a1207765\materiales.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

	  
	  
SELECT  * FROM Materiales