
BULK INSERT a1207765.a1207765.[Proyectos]
   FROM 'e:\wwwroot\a1207765\proyectos.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

SELECT  * FROM Proyectos