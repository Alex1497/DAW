
/*Ejercicio 1-------------------------------------------------------------------------------------------------------------------------*/
/*Crear tablas*/

/*Materiales*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Materiales') 
DROP TABLE Materiales 
CREATE TABLE Materiales 
( 
  Clave numeric(5) not null, 
  Descripcion varchar(50), 
  Costo numeric (8,2) 
) 

/*Proveedores*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Proveedores')
DROP TABLE Proveedores 
CREATE TABLE Proveedores 
( 
  RFC char(13) not null, 
  RazonSocial varchar(50) 
) 

/*Proyectos*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Proyectos') 
DROP TABLE Proyectos
CREATE TABLE Proyectos 
( 
  Numero numeric(5) not null, 
  Denominacion varchar(50) 
) 

/*Entregan*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Entregan') 
DROP TABLE Entregan
CREATE TABLE Entregan 
( 
  Clave numeric(5) not null, 
  RFC char(13) not null, 
  Numero numeric(5) not null, 
  Fecha DateTime not null, 
  Cantidad numeric (8,2) 
) 

/*Cargar Tablas*/
   BULK INSERT a1207765.a1207765.[Materiales]
   FROM 'e:\wwwroot\a1207765\materiales.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

   BULK INSERT a1207765.a1207765.[Proyectos]
   FROM 'e:\wwwroot\a1207765\proyectos.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

   BULK INSERT a1207765.a1207765.[Proveedores]
   FROM 'e:\wwwroot\a1207765\proveedores.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

   SET DATEFORMAT dmy

   BULK INSERT a1207765.a1207765.[Entregan]   
   FROM 'e:\wwwroot\a1207765\entregan.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

/*Ejercicio 2--------------------------------------------------------------------------------------------------------------------------*/

/*Agregar elemento*/
INSERT INTO Materiales values(1000,'xxx',1000)

/*Eliminar Elemento*/
DELETE FROM Materiales WHERE Clave = 1000 and Costo = 1000 

/*Definir Clave como llave primaria*/
ALTER TABLE Materiales ADD CONSTRAINT llaveMateriales PRIMARY KEY (Clave) 

/*Verificar Constraint*/
 sp_helpconstraint Materiales
 sp_helpconstraint Proveedores
 sp_helpconstraint Proyectos
 sp_helpconstraint Entregan

/*Definir llaves primarias*/
ALTER TABLE Proveedores 
ADD CONSTRAINT llaveProveedores 
PRIMARY KEY (RFC) 

ALTER TABLE Proyectos
ADD CONSTRAINT llaveProyectos 
PRIMARY KEY (Numero) 

ALTER TABLE Entregan 
ADD CONSTRAINT llaveEntregan 
PRIMARY KEY (Clave, RFC, Numero, Fecha) 


/*Ejercicio 3----------------------------------------------------------------------------------------------------------------------*/

  SELECT * FROM Materiales
  SELECT * FROM Proveedores
  SELECT * FROM Proyectos
  SELECT * FROM Entregan

	
 INSERT INTO Entregan 
 VALUES (0, 'xxx', 0, '1-jan-02', 0) 

 Delete FROM Entregan 
 WHERE Clave = 0 

 /* Insertar clave foranea*/
 ALTER TABLE Entregan 
 ADD CONSTRAINT cfentreganclave 
 FOREIGN KEY (Clave) 
 REFERENCES Materiales(Clave) 

 ALTER TABLE Entregan 
 ADD CONSTRAINT cfentreganrfc
 FOREIGN KEY (RFC) 
 REFERENCES Proveedores(RFC) 

 ALTER TABLE Entregan 
 ADD CONSTRAINT cfentregannumero
 FOREIGN KEY (Numero) 
 REFERENCES Proyectos(Numero) 

 /*Verificar Constraint*/
 sp_helpconstraint Materiales
 sp_helpconstraint Proveedores
 sp_helpconstraint Proyectos
 sp_helpconstraint Entregan

/*Ejercicio 4 ------------------------------------------------------------------------------------------------------------------------*/

 INSERT INTO Entregan 
 VALUES (1000, 'AAAA800101', 5000, GETDATE(), 0)

 SELECT * FROM Entregan

Delete FROM Entregan
WHERE RFC='AAAA800101' AND Cantidad='0'

ALTER TABLE Entregan 
ADD CONSTRAINT cantidad 
CHECK (cantidad > 0)

/*Verificar Constraint*/
 sp_helpconstraint Materiales
 sp_helpconstraint Proveedores
 sp_helpconstraint Proyectos
 sp_helpconstraint Entregan





